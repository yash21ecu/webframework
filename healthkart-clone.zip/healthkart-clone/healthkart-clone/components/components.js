function footer(){
    return`
    <div id="fotter_container">
    <div id="showupper">
      <div id="upper_fotter">
        <div class="inupper">
          <img
            src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/hk-cash-icon.svg"
            alt=""
          />
          <h3>Earn HK Cash</h3>
          <p>
            Shop with us and get HK Cash to redeem on your next purchase.
            Know more about HK Cash
          </p>
        </div>

        <div class="inupper">
          <img
            src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/safe-payment-icon.svg"
            alt=""
          />
          <h3>Safe Payments</h3>
          <p>
            Pay with the world’s most popular and secure payment methods.
          </p>
        </div>

        <div class="inupper">
          <img
            src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/authenticity-icon.svg"
            alt=""
          />
          <h3>Authenicity Delivered</h3>
          <p>100% authentic products to our customers</p>
        </div>

        <div class="inupper" id="raj">
          <div id="imghold">
            <img
              src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/andriod-icon.svg"
              alt=""
            />
            <img
              src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/apple-icon.svg"
              alt=""
            />
          </div>
          <h3>Download Healthkart App</h3>
          <p>Get the best experience of Healthkart at your fingertips.</p>
          <div id="imghold2">
            <img
              src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/playstore-icon.svg"
              alt=""
            />
            <img
              src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/appstore-icon.svg"
              alt=""
            />
          </div>
        </div>
      </div>
      <div id="upper_fotter2">
        <p>
          <span id="plus">➕</span> More Details about Health, Nutrition &
          Body Building Supplements
        </p>
      </div>
  </div>
 
  <div id="lastfooter">
    <div>
      <ul type="none">
        <li><p class="lasthead1">HEALTHCART</p></li>
       <a id="greylink"href=" "><li>About Us</li></a>
       <a id="greylink" href=" "><li>Contact Us</li></a>
       <a id="greylink"href=" "><li>Refer & Earn</li></a>
       <a id="greylink" href=" "><li>Loyalty Program</li></a>
       <a id="greylink" href=" "><li>HK Consult</li></a>
       <a id="greylink" href=" "><li>Blogs, Videos & More</li></a>
       <a id="greylink" href=" "><li>Brand Directory</li></a>
       <a id="greylink" href=" "><li>Authenicity</li></a>
       <a id="greylink" href=" "><li>Guaranteed</li></a>
       <a id="greylink" href=" "><li>Careers</li></a>
     </ul>
    </div>
    <div>
      <ul type="none">
        <li><p class="lasthead1">BRANDS</p></li>
       <a id="greylink"href=" "><li>MuscleBlaze</li></a>
       <a id="greylink" href=" "><li>TrueBasics</li></a>
       <a id="greylink"href=" "><li>JustHer</li></a>
       <a id="greylink" href=" "><li>Nouriza</li></a>
       <a id="greylink" href=" "><li>Gritzo</li></a>
       <a id="greylink" href=" "><li>bGREEN</li></a>
     </ul>
    </div>
    <div>
      <ul type="none">
        <li><p class="lasthead1">HEALTH & FITNESS</p></li>
       <a id="greylink"href=" "><li>Bodybuilding</li></a>
       <a id="greylink" href=" "><li>Weight Loss</li></a>
       <a id="greylink"href=" "><li>Hair & Skin Care</li></a>
       <a id="greylink" href=" "><li>Sports Nutrition</li></a>
       <a id="greylink" href=" "><li>Vitamins & Supplements</li></a>
       <a id="greylink" href=" "><li>Ayurveda & Herbs</li></a>
       <a id="greylink" href=" "><li>Health Food & Drinks</li></a>
       <a id="greylink" href=" "><li>Fitness</li></a>
       <a id="greylink" href=" "><li>Wellness</li></a>
       <a id="greylink"href=" "><li>Consult Plans</li></a>
     </ul>
    </div>
    <div>
      <ul type="none">
        <li><p class="lasthead1">POLICIES</p></li>
       <a id="greylink"href=" "><li>Terms & Conditions</li></a>
       <a id="greylink" href=" "><li>Delivery Policy</li></a>
       <a id="greylink" href=" "><li>Privacy Policy</li></a>
       <a id="greylink" href=" "><li>Returns Policy</li></a>
     </ul>
    </div>
    <div>
      <ul type="none">
        <li><p class="lasthead1">QUICK LINKS</p></li>
       <a id="greylink"href=" "><li>My Account</li></a>
       <a id="greylink" href=" "><li>Track Your Order</li></a>
       <a id="greylink"href=" "><li>Store Locator</li></a>
       <a id="greylink" href=" "><li>HK Cash</li></a>
       <a id="greylink" href=" "><li>HK Coupons</li></a>
       <a id="greylink" href=" "><li>FAQs</li></a>
       <a id="greylink" href=" "><li>Sell On HealthKart</li></a>
     </ul>
    </div>
    <div>
      <ul type="none">
        <li><p class="lasthead1">ABOUT HEALTHKART</p></li>
      <a id="greylink" href=" "><li>HealthKart.com is India’s largest online health & fitness store for men and women. Shop online from the latest collections of health, fitness and similar products featuring the best brands.
       <br>
       <p class="newsletter"> SUBSCRIBE TO OUR NEWSLETTER </p>
        Be the first one to receive amazing offers, deals and news</li></a>
     <li> <div class="emailsub">
        <input type="email" placeholder="Enter your email" />
        <button class="newbutton">SUBSCRIBE</button>
      </div>
      </li>.
      <li><p class="contactlogos">CONNECT WITH US</p></li>
      <img class="logoimg" src="https://merchantsmtg.com/wp-content/uploads/2021/02/5cf741e3c6578da50df09b998a5117cc.jpg">
    </ul>
    </div>
  </div>
  <br>
  <div class="disclaimer">
    <div class="leftdis">
      <div class="newlogo"><img src="https://static1.hkrtcdn.com/hknext/static/media/common/footer/hk-consult.svg"></div>
      <div class="newlogo"><img src="https://static1.hkrtcdn.com/hknext/static/media/common/footer/A-G.svg"></div>
   
        <div class="newlogo"> <img src="https://static1.hkrtcdn.com/hknext/static/media/common/footer/RP.svg"> </div>
       
      </div>
      <div class="rightdis">
        <b>Disclaimer: </b>The information contained on HealthKart (www.healthkart.com or subdomains) is provided for informational purposes only and is not meant to substitute for the advice provided by your doctor or other healthcare professional. Information and statements regarding products, supplements, programs etc listed on HealthKart have not been evaluated by the Food and Drug Administration or any government authority and are not intended to diagnose, treat, cure, or prevent any disease. Please read product packaging carefully prior to purchase and use. The results from the products will vary from person to person. No individual result should be seen as typical.
        
      </div>
  </div>
`
}


function navbarfirst(){
    return `
    <div id="navbar">
    <div class="container">
      <div class="logo">
        <a href="index.html"><img
          src="https://upload.wikimedia.org/wikipedia/commons/f/fa/Healthkart.png"
          alt=""
          width="250"
          height="80"
        /></a>
      </div>
      <div class="search-div">
        <img
          id="searchpng"
          src="https://static1.hkrtcdn.com/hknext/static/media/common/header/search-icon-grey-2.svg"
          alt=""
        />
        <input
          type="text"
          placeholder="Search for products, brands or Health Goals"
        />
      </div>

      <div class="nav-items">

        <div class="item-1">
          <p>Loyalty Rewards</p>
          
        </div>
         <p class="border1"></p>
         <ul>
        <li><div class="item-2"> <p>Customer Support</p></div>
          <ul style="width:300px;height:300px";>
            <li style="font-size: 14px; font-weight: bold;"><a  id="blacklink" href="">Contact Us</a></li>
            <li style="font-size: 14px; font-weight: bold;"><a  id="blacklink" href="">Helpful Links</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">Chat With US</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">Track Your Order</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">Email Us</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">Return Policy</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">Ask Our Experts</a></li>
            <li style="font-size: 14px;"><a  id="blacklink" href="">FAQ</a></li>
            
          </ul>
          </li>
          </ul>
          
        <div class="arrow">
          <img
            src="https://static1.hkrtcdn.com/hknext/static/media/common/header/arrow-down.svg"
          />
        </div>
        <p class="border2"></p>
        <div class="acc">
          <img
            src="https://static1.hkrtcdn.com/hknext/static/media/common/header/acc-icon.svg"
          />
        </div>
        <ul>
        <li><div class="item-3" id="go_to_login_page"><p>My Accounts and Orders</p></div>
          <ul style="width:300px;height:300px";>
            <li style="width:300px;height:50px">
              <button class="loginbutton" onclick="myLoginFunction()">Login</button>
            </li>
            <br>
            <li style="width:300px;height:50px;margin-top: 10px;">
              <button class="newuserbutton" onclick="myLoginFunction()">New User? / Sign Up</button>
            </li>
            <br>
            <li>
              <p style="color:  #00c2c1;">My Account</p>

            </li>
            <li>
              <p style="color:  #00c2c1;">Health Profile</p>
              
            </li>
            <li>
              <p>Orders</p>
              
            </li>
            <li>
              <p>Diet Plan</p>
              
            </li>
            <li>
              <p>Wishlist</p>
              
            </li>
            <li>
              <p>My Consultations</p>
              
            </li>
            <li>
              <p>Royalty Reward</p>
              
            </li>
            <li>
              <p>Recommended Product</p>
              
            </li>
            <br>
            <br>
            
            
          </ul>
          </li>
          </ul>
       
        <p class="border3"></p>
      </div>
      <div class="cart">
        <a href="cart.html">
          <img id="gotocart"
          src="https://static1.hkrtcdn.com/hknext/static/media/common/header/cart.svg"
          alt="cart"
          height="25px"
          />
        <p id="cart_quantity">0</p>
        </a>
      </div>
    </div>
  </div>

  <div id="nav" class="navbar2">
    <ul>
      <li> <div class="nav-items-1"><p>Category</p></div>
        <ul>
          <li><a  id="blacklink" href="">Sports Nutrition</a></li>
          <li><a  id="blacklink" href="">Vitamins & Supplements</a></li>
          <li><a  id="blacklink" href="">Ayurveda & Herbs</a></li>
          <li><a  id="blacklink" href="">Health Food & Drinks</a></li>
          <li><a  id="blacklink" href="">Fitness</a></li>
          <li><a  id="blacklink" href="">Wellness</a></li>
          <li><a  id="blacklink" href="">Service Program</a></li>
          
        </ul></li>
        <li> <div class="nav-items-2"><p>Brand</p> </div>
            
          <ul>
            <li><a  id="blacklink" href="">MuscleBlaze <br>     </a></li>
            <li><a  id="blacklink" href="">TrueBasics</a></li>
            <li><a  id="blacklink" href="">JustHer</a></li>
            <li><a  id="blacklink" href="">Nouriza</a></li>
            <li><a  id="blacklink" href="">Gritzo</a></li>
            <li><a  id="blacklink" href="">bGREEN</a></li>
            <li><a  id="blacklink" href="">GNC</a></li>
            <li><a  id="blacklink" href="">NOW</a></li>
            <li><a  id="blacklink" href="">Healthvit</a></li>
            <li><a  id="blacklink" href="">Yoga Bar</a></li>
            <li><a  id="blacklink" href="">Amway</a></li>
            <li><a  id="blacklink" href="">Natures Velvet</a></li>
            
          </ul>
            
    
        </li>
        <li>
          <div class="nav-items-3"><p>Gender</p></div>
          <ul style="width:200px;height:100px";>
            <li><a  id="blacklink" href=""> <img src="https://static1.hkrtcdn.com/hknext/static/media/common/header/man-2.svg"></a></li>
            <li><a  id="blacklink" href=""><img src="https://static1.hkrtcdn.com/hknext/static/media/common/header/woman-2.svg"></a></li>
    
          </ul>
        </li>
        <li>
          <div class="nav-items-4"><p>Goal</p></div>
          <ul style="width:700px;height:300px; ";>
            <li ><a  id="blacklink" href=""><img style="width:80px;height:80px"; src="https://img6.hkrtcdn.com/14784/normal_1478355_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:80px;height:80px"; src="https://img8.hkrtcdn.com/14784/normal_1478357_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:80px;height:80px"; src="https://img10.hkrtcdn.com/14784/normal_1478359_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:80px;height:80px"; src="https://img2.hkrtcdn.com/14784/normal_1478361_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:80px;height:80px"; src="https://img4.hkrtcdn.com/14784/normal_1478363_o.png"></a></li>
            
          </ul>
        </li>
        <li>
          <div class="nav-items-5"><p>Bestsellers</p></div>
          <ul>
            <li><a  id="blacklink" href="">Sport Nutrition</a></li>
            <li><a  id="blacklink" href="">Protein Poweder</a></li>
            <li><a  id="blacklink" href="">Whey Proteins</a></li>
            <li><a  id="blacklink" href="">Mass Gainer</a></li>
            <li><a  id="blacklink" href="">Fat Burners</a></li>
            <li><a  id="blacklink" href="">Pre WorkOut</a></li>
            <li><a  id="blacklink" href="">Protein Bars</a></li>
            <li><a  id="blacklink" href="">Weight Gainer</a></li>
            <li><a  id="blacklink" href="">Carb Blends</a></li>
            <li><a  id="blacklink" href="">Other Supports</a></li>
          </ul>

        </li>
        <li>
          <div class="nav-items-6"><p>Deals</p></div>
          <ul style="width:700px;height:300px ";>
            <li><a  id="blacklink" href=""><img style="width:120px;height:60px"; src="https://img4.hkrtcdn.com/14768/normal_1476713_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:120px;height:60px"; src="https://img8.hkrtcdn.com/14768/normal_1476717_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:120px;height:60px"; src="https://img2.hkrtcdn.com/14768/normal_1476721_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:120px;height:60px"; src="https://img10.hkrtcdn.com/14768/normal_1476719_o.png"></a></li>
            <li><a  id="blacklink" href=""><img style="width:120px;height:60px"; src="https://static1.hkrtcdn.com/hknext/static/media/common/misc/crazy.svg"></a></li>
          </ul>
        </li>
        <li>
          <div class="nav-items-7"><p><a href="giftcard.html">Gift Card</a></p></div>

        </li>
        <!-- <li>
          <div class="nav-items-8"><p><a href="blog.html">Blog, Videos & More</a></p></div>
        </li> -->
      </ul>
    <!-- <div class="nav-items-1"><p>Category</p></div>
    <div class="nav-items-2"><p>Brand</p></div>
    <div class="nav-items-3"><p>Gender</p></div>
    <div class="nav-items-4"><p>Goal</p></div>
    <div class="nav-items-5"><p>Bestsellers</p></div>
    <div class="nav-items-6"><p>Deals</p></div>
    <div class="nav-items-7"><p><a href="giftcard.html">Gift Card</a></p></div>
    <div class="nav-items-8"><p><a href="blog.html">Blog, Videos & More</a></p></div> -->

    <div class="rightPart">
      <div class="consult">
        <img
          class="video"
          src="	https://static1.hkrtcdn.com/hknext/static/media/common/header/hk-consult.svg"
          height="13px"
        />
        <p>HK Consult</p>
      </div>
      <div class="findStore">
        <img
          class="icon"
          src="https://static1.hkrtcdn.com/hknext/static/media/common/header/location-pin.svg"
        />
        <p><a href="stores.html">Find a Store</a></p>
      </div>
    </div>
  </div>`
}



export {footer,navbarfirst}
